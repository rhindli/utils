#!/bin/bash

TEMP_CLASSPATH=$CLASSPATH
CLASSPATH=".;./lib/bcel-5.2.jar;./lib/jakarta-regexp-1.3.jar;./lib;./jaranalyzer-1.2.jar"
java -classpath .:./lib/bcel-5.2.jar:./lib/jakarta-regexp-1.3.jar:./lib:./jaranalyzer-1.2.jar com.kirkk.analyzer.textui.XMLUISummary $1 $2
CLASSPATH=$TEMP_CLASSPATH
TEMP_CLASSPATH=